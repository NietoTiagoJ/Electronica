#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>
#include <map>
#include <fstream>
#include "./serialib/lib/serialib.h"  

#define SERIAL_PORT "/dev/ttyACM0"

serialib serial;

using namespace std;

class Usuario {
public:
    uint8_t id;
    string nombreUsuario;
    int contador;
    int porcentaje;

    Usuario() : id(0), nombreUsuario(""), contador(0), porcentaje(0) {}

    Usuario(uint8_t id, string nombreUsuario, int contador, int porcentaje)
        : id(id), nombreUsuario(nombreUsuario), contador(contador), porcentaje(porcentaje) {}

    void actualizarDatos(uint8_t id, string nombreUsuario, int contador, int porcentaje) {
        this->id = id;
        this->nombreUsuario = nombreUsuario;
        this->contador = contador;
        this->porcentaje = porcentaje;
    }

    string datosEnFormato() const {
        return "Usuario: " + nombreUsuario + "\nID: " + to_string(id) + "\nContador: " + to_string(contador) + "\nPorcentaje: " + to_string(porcentaje) + "\n";
    }
};

void actualizarArchivo(map<string, Usuario>& usuarioMap) {
    ofstream archivo("datos.txt");
    if (!archivo.is_open()) {
        cout << "NO se abrió el archivo" << endl;
        return;
    }
    
    for (const auto& entry : usuarioMap) {
        archivo << entry.second.datosEnFormato() << endl;
    }

    archivo.close();
}

void procesarMensaje(const vector<char>& mensaje, map<string, Usuario>& usuarioMap) {
    if (mensaje.size() < 8) { 
        cout << "Mensaje demasiado corto: ";
        for (char c : mensaje) cout << c;
        cout << endl;
        return;
    }

    //(0xFF)
    if (mensaje[0] != static_cast<char>(0xFF)) {
        cout << "Indicador de inicio no encontrado" << endl;
        return;
    }

    //(0xFE)
    if (mensaje[mensaje.size() - 1] != static_cast<char>(0xFE)) {
        cout << "Indicador de fin no encontrado" << endl;
        return;
    }

    // id
    uint8_t id = static_cast<uint8_t>(mensaje[1]);

    //nombre
    size_t pos = find(mensaje.begin() + 2, mensaje.end(), '\0') - mensaje.begin();
    if (pos == mensaje.size()) {
        cout << "Delimitador nulo no encontrado en el nombre de usuario" << endl;
        return;
    }
    string nombreUsuario(mensaje.begin() + 2, mensaje.begin() + pos);

   
    if (pos + 5 > mensaje.size()) {
        cout << "Datos incompletos para los enteros" << endl;
        return;
    }

    int contador = (static_cast<uint8_t>(mensaje[pos + 1]) << 8) | static_cast<uint8_t>(mensaje[pos + 2]);
    int porcentaje = (static_cast<uint8_t>(mensaje[pos + 3]) << 8) | static_cast<uint8_t>(mensaje[pos + 4]);

    if (usuarioMap.find(nombreUsuario) != usuarioMap.end()) {
        usuarioMap[nombreUsuario].actualizarDatos(id, nombreUsuario, contador, porcentaje);
    } else {
        Usuario nuevoUsuario(id, nombreUsuario, contador, porcentaje);
        usuarioMap[nombreUsuario] = nuevoUsuario;
    }

    
    actualizarArchivo(usuarioMap);
}

int main() {
    
    char errorOpening = serial.openDevice(SERIAL_PORT, 9600);  // 9600

    if (errorOpening != 1) {
        cout << "Error al abrir el puerto serial: " << errorOpening << endl;
        return errorOpening;
    }

    cout << "Conexión establecida con Arduino en el puerto " << SERIAL_PORT << endl;

    map<string, Usuario> usuarioMap;  
    vector<char> buffer;  
    char tempBuffer[256];  

    while (true) {
       
        int bytesRead = serial.readString(tempBuffer, sizeof(tempBuffer) - 1, 2000);  // Timeout de 2 segundos
        if (bytesRead > 0) {
            buffer.insert(buffer.end(), tempBuffer, tempBuffer + bytesRead);

            
            auto startPos = find(buffer.begin(), buffer.end(), static_cast<char>(0xFF));
            while (startPos != buffer.end()) {
                
                auto endPos = find(startPos, buffer.end(), static_cast<char>(0xFE));
                if (endPos != buffer.end()) {
                    
                    vector<char> mensaje(startPos, endPos + 1);
                    procesarMensaje(mensaje, usuarioMap);

                    
                    buffer.erase(buffer.begin(), endPos + 1);
                } else {
                    
                    break;
                }
                
                startPos = find(buffer.begin(), buffer.end(), static_cast<char>(0xFF));
            }
        } else {
            cout << "No se recibieron datos, intentándolo de nuevo..." << endl;
        }
    }

    
    serial.closeDevice();

    return 0;
}

